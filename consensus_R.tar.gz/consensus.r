consensus<-function(distMats, nk = seq(2, 20, 1), 
                    mode="AVERAGED", par = F, ncores=1){
  
  if(missing(distMats) | length(distMats)==0 | !is.list(distMats))
    stop("need to supply a list of distance matrices")
  
    if(!require(cluster))
    stop("cluster package needs to be installed")
  if(!require(GraphAT))
    stop("GraphAT package needs to be installed")
  if(!require(foreach))
    stop("foreach package needs to be installed")

  if(par){
    if(!require(doParallel))
      stop("you have set the parallel option but doParallel package needs to be loaded")
    registerDoParallel(cores = ncores)
  }
  
  if(!mode %in% c("AVERAGED", "LIST"))
    stop("mode must be either AVERAGED or LIST")
  
  #number of nodes
  nNodes<-length(distMats)
  #number of subjects
  nSub<-nrow(distMats[[1]])
  
  listConsMat<-foreach(iclus=nk, .packages = c("cluster", "GraphAT")) %dopar%{
    
    #empty consensus matrix for each partition
    consMat<-matrix(rep(0, nSub*nSub), nrow = nSub)
    #average on nodes
    for(i in c(1:nNodes)){
      
      regioneMat<-distMats[[i]]
      
      clusIndex<-pam(regioneMat, k = iclus, diss = T)$clustering
      
      #adjacency matrix from clustering members
      adjMat<-clust2Mat(clusIndex)
      consMat<- consMat + adjMat
    }
    
    
    message("consensus with k= ", iclus, " finished ")  
    
    as.matrix(consMat/nNodes)
  
  }
  

  if(mode=="AVERAGED"){
    return(Reduce("+", listConsMat)/length(listConsMat))
  }
  else if(mode == "LIST")
    return(listConsMat)
}